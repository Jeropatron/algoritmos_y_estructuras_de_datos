# TP 1 — Registro de préstamos de la biblioteca

**CB100 — Algoritmos y Estructuras de Datos · 2.º cuatrimestre 2026**
Jerónimo Patrón — Padrón 115438 — jeropatron@gmail.com

Programa por consola que procesa el registro de préstamos de la biblioteca de FIUBA. Lee el archivo de préstamos, valida cada línea (descartando las que tienen errores, sin cortar la ejecución) y genera un reporte con el detalle de multas por socio y un ranking de los títulos más pedidos.

## Requisitos

- **JDK 25** (o una versión superior compatible).
- No hace falta instalar Gradle: el proyecto trae el *wrapper* (`gradlew`), que baja la versión correcta solo. La primera ejecución necesita conexión a internet para descargar Gradle y las dependencias.

## Cómo ejecutarlo

Desde la raíz del proyecto (donde está `gradlew`):

```bash
./gradlew run
```

Toma 2 argumentos **opcionales**: el archivo de entrada y la fecha de corte. Si no se pasan, usa los valores por defecto (el `prestamos.csv` de la carpeta `datos` y la fecha `2026-05-04`). Para pasar otros:

```bash
./gradlew run --args="otra/ruta/prestamos.csv 2026-06-01"
```

## Qué genera

Imprime por consola un resumen de la carga (líneas totales, válidas y descartadas, con el motivo de cada descarte) y escribe tres archivos en la raíz:

- `reporte.txt` — reporte de texto con columnas alineadas, totales y ranking de títulos.
- `reporte.csv` — los mismos datos, con los campos separados por `;`.
- `reporte.xlsx` — una planilla de Excel con la tabla por socio (punto adicional).

## Tests

Para correr las pruebas (15 tests con JUnit 5):

```bash
./gradlew test
```

## Documentación

El informe del trabajo, las respuestas al cuestionario y los manuales de usuario y del programador están en `TrabajoPractico1.pdf`.
