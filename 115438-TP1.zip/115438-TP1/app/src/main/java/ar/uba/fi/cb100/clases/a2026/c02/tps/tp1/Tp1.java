package ar.uba.fi.cb100.clases.a2026.c02.tps.tp1;

import java.io.IOException;
import java.nio.file.Path;
import java.time.LocalDate;

/**
 * La clase principal del proyecto. Conecta todas las otras clases para el
 * correcto funcionamiento. Lee los argumentos con defaults, carga el archivo,
 * imprime el resumen por consola, arma el reporte y exporta reporte.txt,
 * reporte.csv y reporte.xlsx.
 */
public class Tp1 {
    private static final String ENTRADA_POR_DEFECTO = "app/src/main/java/ar/uba/fi/cb100/clases/a2026/c02/tps/tp1/datos/prestamos.csv";

    private static final LocalDate CORTE_POR_DEFECTO = LocalDate.parse("2026-05-04");

    /**
     * Punto de entrada del programa.
     *
     * Precondicion: ninguna.
     * Postcondicion: lee los argumentos (con valores por defecto), carga el archivo,
     * imprime el resumen por consola, arma el reporte y exporta reporte.txt,
     * reporte.csv y reporte.xlsx.
     *
     * @param args el archivo de entrada y la fecha de corte (ambos opcionales).
     * @throws IOException si no se puede leer o escribir algún archivo.
     */
    static void main(String[] args) throws IOException {
        Path archivo = Path.of((args.length > 0) ? args[0] : ENTRADA_POR_DEFECTO);

        LocalDate corte = (args.length > 1) ? LocalDate.parse(args[1]) : CORTE_POR_DEFECTO;

        ResultadoDeCarga resultado = LectorDePrestamos.cargar(archivo);

        System.out.println("Lineas de datos: " + resultado.lineasDeDatos() + " | validas: " + resultado.registro().cantidad() + " | descartadas: " + resultado.errores().length);

        for (int i = 0; i < resultado.errores().length; i++) {
            System.out.println(" " + resultado.errores()[i]);
        }

        FilaDeSocio[] filas = Reporteador.porSocio(resultado.registro(), corte);

        String[] ranking = Reporteador.ranking(resultado.registro(), 3);

        int[] conteos = new int[ranking.length];

        for (int j = 0; j < ranking.length; j++) {
            int cont = 0;

            for (int k = 0; k < resultado.registro().cantidad(); k++) {
                if (resultado.registro().obtener(k).titulo().equals( ranking[j] )) {
                    cont ++;
                }


            }
            conteos[j] = cont;
        }

        ExportadorDeReporte exportadorReporte = new ExportadorTxt(corte, ranking, conteos);

        Path destinoReporte = Path.of("reporte." + exportadorReporte.extension());

        ExportadorCsv exportadorCsv = new ExportadorCsv();

        Path destinoCsv = Path.of("reporte." + exportadorCsv.extension());

        exportadorReporte.exportar(filas, destinoReporte);

        exportadorCsv.exportar(filas, destinoCsv);

        ExportadorXlsx exportadorxlsx = new ExportadorXlsx();

        Path destinoXlsx = Path.of("reporte." + exportadorxlsx.extension());

        exportadorxlsx.exportar(filas, destinoXlsx);

    }

}
