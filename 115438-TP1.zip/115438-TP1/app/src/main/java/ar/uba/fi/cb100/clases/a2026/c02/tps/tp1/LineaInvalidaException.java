package ar.uba.fi.cb100.clases.a2026.c02.tps.tp1;

/**
 * Excepción propia que hereda de RuntimeException para una línea inválida del
 * archivo. Guarda el número de línea y el motivo.
 */
public class LineaInvalidaException extends RuntimeException {

    private int numeroDeLinea;

    /**
     * Crea la excepción con el número de línea y el motivo.
     *
     * Precondicion: ninguna.
     * Postcondicion: crea la excepción, pasa el motivo al mensaje y guarda el
     * número de línea.
     *
     * @param numeroDeLinea el número de línea donde está el error.
     * @param motivo el motivo del error.
     */
    public LineaInvalidaException(int numeroDeLinea, String motivo) {
        super(motivo);

        this.numeroDeLinea = numeroDeLinea;
    }

    /**
     * Devuelve el número de línea donde se encuentra el error.
     *
     * Precondicion: ninguna.
     * Postcondicion: devuelve el número de línea donde se encuentra el error.
     * No modifica el estado.
     *
     * @return el número de línea donde se encuentra el error.
     */
    public int numeroDeLinea() {

        return numeroDeLinea;
    }
}
