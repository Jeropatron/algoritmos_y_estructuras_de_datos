package ar.uba.fi.cb100.clases.a2026.c02.tps.tp1;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Arrays;
import java.util.List;

/**
 * Lee el archivo de préstamos, parsea cada línea y arma el registro,
 * descartando las líneas inválidas.
 */
public class LectorDePrestamos {

    /**
     * Devuelve el resultado de la carga del registro.
     *
     * Precondicion: ninguna.
     * Postcondicion: devuelve el resultado de la carga del registro.
     * Saltea las líneas en blanco y las que empiezan con #, y en caso de
     * encontrar un error en una línea, atrapa LineaInvalidaException
     * guardando el error con su respectivo número de línea y mensaje,
     * sin cortar la ejecución.
     *
     * @param archivo el archivo de préstamos a cargar.
     * @return el resultado de la carga.
     * @throws IOException si no se puede leer el archivo.
     */
    public static ResultadoDeCarga cargar(Path archivo) throws IOException {

        RegistroSobreArreglo registro = new RegistroSobreArreglo();

        List<String> lineas = Files.readAllLines(archivo);

        int numeroDeLineas = lineas.size();

        String[] errores = new String[numeroDeLineas];

        int totalErrores = 0;

        int lineasDeDatos = 0;

        for (int i = 0; i < numeroDeLineas; i++) {
            String linea = lineas.get(i);

            if (linea.isBlank() || linea.startsWith("#")) {
                continue;
            }

            lineasDeDatos += 1;

            try {
                Prestamo prestamo = parsearLinea(linea, i + 1);

                registro.registrar(prestamo);

            } catch (LineaInvalidaException e) {
                errores[totalErrores] = "Linea " + e.numeroDeLinea() + ": " + e.getMessage();

                totalErrores += 1;

            }
        }

        return new ResultadoDeCarga(registro, Arrays.copyOf(errores, totalErrores), lineasDeDatos);

    }

    /**
     * Verifica la integridad de cada línea parseándola.
     *
     * Precondicion: ninguna.
     * Postcondicion: devuelve el Prestamo parseado. En caso de que los campos sean
     * distintos de 6 o que haya un error de formato en alguno, lanza
     * LineaInvalidaException con su respectivo mensaje.
     *
     * @param linea la línea a parsear.
     * @param numeroDeLinea el número de línea, para el mensaje de error.
     * @return el Prestamo parseado.
     */
    private static Prestamo parsearLinea(String linea, int numeroDeLinea) {
        String[] lineaCortada = linea.split(";", -1);

        if (lineaCortada.length != 6) {
            throw new LineaInvalidaException(numeroDeLinea, "se esperaban 6 campos y llegaron " + lineaCortada.length);
        }

        try {
            LocalDate pidio = LocalDate.parse(lineaCortada[0]);

            int textoNumerico = Integer.parseInt(lineaCortada[1].strip());

            String socio = lineaCortada[2].strip();

            String isbn = lineaCortada[3].strip();

            String titulo = lineaCortada[4].strip();

            LocalDate devolucion;

            if (lineaCortada[5].isBlank()) {
                devolucion = null;
            } else {
                devolucion = LocalDate.parse(lineaCortada[5].strip());
            }

            return new Prestamo(pidio, textoNumerico, socio, isbn, titulo, devolucion);

        } catch (DateTimeParseException excepcionFecha) {
            throw new LineaInvalidaException(numeroDeLinea, "fecha invalida");

        } catch (NumberFormatException excepcionPadron) {
            throw new LineaInvalidaException(numeroDeLinea, "Padron invalido");

        } catch (IllegalArgumentException excepcionStrings) {
            throw new LineaInvalidaException(numeroDeLinea, excepcionStrings.getMessage());

        }

    }
}