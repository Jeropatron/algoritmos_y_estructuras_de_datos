package ar.uba.fi.cb100.clases.a2026.c02.tps.tp1;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/** Representa un Prestamo que es inmutable, validando las invariantes en el constructor. */
public record Prestamo(LocalDate retiro, int padron, String socio, String isbn, String titulo, LocalDate devolucion) {

    /**
     * Valida las invariantes del préstamo al crearlo.
     *
     * Precondicion: padron > 0, socio, isbn y titulo no son nulos ni vacíos,
     * si devolucion no es nula, no es anterior al retiro.
     * Postcondicion: crea el préstamo, o lanza IllegalArgumentException si algún dato no cumple la invariante.
     */
    public Prestamo {
        if (padron <= 0) {
            throw new IllegalArgumentException("El padron no puede ser menor o igual a 0.");
        }

        if (socio == null || socio.isEmpty()) {
            throw new IllegalArgumentException("El nombre del socio no puede estar vacio ni ser nulo.");
        }

        if (isbn == null || isbn.isEmpty()) {
            throw new IllegalArgumentException("El identificador del libro no puede estar vacio ni ser nulo.");
        }

        if (titulo == null || titulo.isEmpty()) {
            throw new IllegalArgumentException("El titulo del libro no puede estar vacio ni ser nulo.");
        }

        if (devolucion != null && devolucion.isBefore(retiro)) {
            throw new IllegalArgumentException("La devolución no puede ser previa al retiro");
        }
    }

    /**
     * Devuelve true si el préstamo sigue en poder del socio (sin fecha de devolución).
     *
     * Precondicion: ninguna.
     * Postcondicion: devuelve true si el préstamo sigue en poder del socio
     * (sin fecha de devolución). No modifica el estado.
     *
     * @return true si el préstamo sigue en poder del socio.
     */
    public boolean estaPendiente() {
        return devolucion == null;
    }

    /**
     * Devuelve la fecha de vencimiento, sumándole 14 días a la fecha de retiro del libro.
     *
     * Precondicion: ninguna.
     * Postcondicion: devuelve la fecha de vencimiento, sumándole 14 días a la fecha
     * de retiro del libro. No modifica el estado.
     *
     * @return la fecha de vencimiento.
     */
    public LocalDate vencimiento() {
        return retiro.plusDays(14);
    }

    /**
     * Calcula la cantidad de días de atraso que lleva el socio.
     *
     * Precondicion: ninguna.
     * Postcondicion: devuelve la cantidad de días de atraso en caso de que este todavía
     * no esté devuelto, o la cantidad de días que se atrasó hasta que lo devolvió,
     * siempre mayor o igual a 0. No modifica el estado.
     *
     * @param corte la fecha de corte.
     * @return la cantidad de días de atraso (siempre mayor o igual a 0).
     */
    public int diasDeAtraso(LocalDate corte) {
        LocalDate fechaHasta = estaPendiente() ? corte : devolucion;

        long entre = Math.max(0, ChronoUnit.DAYS.between(vencimiento(), fechaHasta));

        return (int) entre;
    }

    /**
     * Calcula la multa del socio.
     *
     * Precondicion: ninguna.
     * Postcondicion: cobra $150 por día de atraso, con un tope de $3000,
     * independientemente de si el socio superó ese número. No modifica el estado.
     *
     * @param corte la fecha de corte.
     * @return la multa del socio.
     */
    public int multa(LocalDate corte) {
        int diasTotales = diasDeAtraso(corte);

        int multaBase = diasTotales * 150;

        return Math.min(3000, multaBase);
    }
}
