package ar.uba.fi.cb100.clases.a2026.c02.tps.tp1;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;

/**
 * Implementa el contrato de ExportadorDeReporte sobre el reporte como texto con
 * columnas alineadas.
 */
public class ExportadorTxt implements ExportadorDeReporte{

    private final LocalDate corte;

    private final String[] ranking;

    private final int[] conteos;

    /**
     * Crea el exportador del reporte como texto y guarda el corte, el ranking y los conteos.
     *
     * Precondicion: ninguna.
     * Postcondicion: crea el exportador y guarda el corte, el ranking y los conteos.
     *
     * @param corte la fecha de corte.
     * @param ranking el ranking de títulos.
     * @param conteos los conteos del ranking.
     */
    public ExportadorTxt(LocalDate corte, String[] ranking, int[] conteos) {
        this.corte = corte;
        this.ranking = ranking;
        this.conteos = conteos;
    }

    /**
     * Escribe el reporte de texto en el archivo destino.
     *
     * Precondicion: ninguna.
     * Postcondicion: escribe el reporte de texto en el archivo destino con los
     * respectivos datos, manteniendo las columnas alineadas con String.format, los
     * totales y el ranking de los títulos.
     *
     * @param filas las filas del reporte.
     * @param destino el archivo donde se escribe.
     * @throws IOException si no se puede escribir el archivo.
     */
    @Override
    public void exportar(FilaDeSocio[] filas, Path destino) throws IOException {

        StringBuilder contenido = new StringBuilder().append("BIBLIOTECA FIUBA - REPORTE DE MULTAS").append("\n").append("Fecha de corte: ").append(corte).append("\n").append("\n").append(String.format("%-8s %-18s %9s %10s %9s %-9s", "Padron", "Socio", "Prestamos", "DiasAtraso", "Multa", "Estado")).append("\n").append("--------------------------------------------------------------------").append("\n");

        int totalPrestamos = 0;
        int totalDiasDeAtraso = 0;
        int totalMultas = 0;

        for (int i = 0; i < filas.length; i++) {
            contenido.append(String.format("%-8d %-18s %9d %10d %9d %-9s", filas[i].padron(), filas[i].socio(), filas[i].prestamos(), filas[i].diasDeAtraso(), filas[i].multa(), filas[i].estado())).append("\n");

            totalPrestamos += filas[i].prestamos();

            totalDiasDeAtraso += filas[i].diasDeAtraso();

            totalMultas += filas[i].multa();
        }

        contenido.append("--------------------------------------------------------------------").append("\n").append(String.format("%-27s %9d %10d %9d", "TOTALES", totalPrestamos, totalDiasDeAtraso, totalMultas)).append("\n").append("\n").append("TÍTULOS MAS PEDIDOS").append("\n");

        for (int j = 0; j < ranking.length; j++) {
            contenido.append(" ").append(j + 1).append(". ").append(String.format("%-30s %d", ranking[j], conteos[j])).append("\n");
        }

        Files.writeString(destino, contenido);
    }

    /**
     * Devuelve la extension del archivo.
     *
     * Precondicion: ninguna.
     * Postcondicion: devuelve la extension del archivo. No modifica el estado.
     *
     * @return la extension del archivo.
     */
    @Override
    public String extension() {

        return "txt";
    }
}
