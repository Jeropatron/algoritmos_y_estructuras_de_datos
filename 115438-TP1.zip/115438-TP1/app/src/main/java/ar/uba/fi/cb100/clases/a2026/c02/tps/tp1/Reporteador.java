package ar.uba.fi.cb100.clases.a2026.c02.tps.tp1;

import java.time.LocalDate;
import java.util.Arrays;

/**
 * Arma las filas del reporte y el ranking.
 */
public class Reporteador {

    /**
     * Devuelve un arreglo de FilaDeSocio por socio con sus respectivos datos.
     *
     * Precondicion: ninguna.
     * Postcondicion: devuelve un arreglo de FilaDeSocio por socio con sus
     * respectivos datos, ordenadas por multa descendente y, en caso de empate,
     * con desempate alfabético por el nombre. No modifica el estado.
     *
     * @param r el registro de préstamos.
     * @param corte la fecha de corte.
     * @return las filas por socio, ordenadas.
     */
    public static  FilaDeSocio[] porSocio(RegistroDePrestamos r, LocalDate corte) {
        int[] padrones = r.padrones();

        FilaDeSocio[] resultado = new FilaDeSocio[padrones.length];

        for (int i = 0; i < padrones.length; i++) {
            Prestamo[] prestamosDelSocio = r.prestamosDe(padrones[i]);

            int totalDiasDeAtraso = 0;

            int totalMulta = 0;

            for (int j = 0; j < prestamosDelSocio.length; j++) {
                totalDiasDeAtraso += prestamosDelSocio[j].diasDeAtraso(corte);

                totalMulta += prestamosDelSocio[j].multa(corte);

            }
            int cantidadDePrestamos = prestamosDelSocio.length;

            String nombreDelSocio = prestamosDelSocio[0].socio();

            String estado = (totalMulta > 0) ? "CON_DEUDA" : "AL_DIA";

            resultado[i] = new FilaDeSocio(padrones[i], nombreDelSocio, cantidadDePrestamos, totalDiasDeAtraso, totalMulta, estado);

        }
        Arrays.sort(resultado, (a, b) -> {
            if (a.multa() != b.multa()) {
                return b.multa() - a.multa();
            }
            return a.socio().compareTo(b.socio());
        });

        return resultado;
    }

    /**
     * Devuelve los n títulos más pedidos.
     *
     * Precondicion: ninguna.
     * Postcondicion: devuelve los n títulos más pedidos. En caso de empate, se hace
     * un desempate alfabético. No modifica el estado.
     *
     * @param r el registro de préstamos.
     * @param n la cantidad de títulos a devolver.
     * @return los n títulos más pedidos.
     */
    public static String[] ranking(RegistroDePrestamos r, int n) {

        return r.titulosMasPedidos(n);
    }
}
