package ar.uba.fi.cb100.clases.a2026.c02.tps.tp1;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Implementa el contrato de ExportadorDeReporte sobre el reporte como CSV.
 */
public class ExportadorCsv implements ExportadorDeReporte{

    /**
     * Escribe el reporte como CSV en el archivo destino.
     *
     * Precondicion: ninguna.
     * Postcondicion: escribe el reporte como CSV en el archivo destino con los
     * respectivos datos: una línea de encabezado y una línea por socio con los
     * campos separados.
     *
     * @param filas las filas del reporte.
     * @param destino el archivo donde se escribe.
     * @throws IOException si no se puede escribir el archivo.
     */
    @Override
    public void exportar(FilaDeSocio[] filas, Path destino) throws IOException {
        StringBuilder contenido = new StringBuilder().append("padron;").append("socio;").append("prestamos;").append("dias_atraso;").append("multa;").append("estado").append("\n");

        for (int i = 0; i < filas.length; i++) {
            contenido.append(filas[i].padron()).append(";").append(filas[i].socio()).append(";").append(filas[i].prestamos()).append(";").append(filas[i].diasDeAtraso()).append(";").append(filas[i].multa()).append(";").append(filas[i].estado()).append("\n");
        }
        Files.writeString(destino, contenido.toString());

    }

    /**
     * Devuelve la extension del archivo.
     *
     * Precondicion: ninguna.
     * Postcondicion: devuelve la extension del archivo. No modifica el estado.
     *
     * @return la extension del archivo.
     */
    @Override
    public String extension() {

        return "csv";
    }
}
