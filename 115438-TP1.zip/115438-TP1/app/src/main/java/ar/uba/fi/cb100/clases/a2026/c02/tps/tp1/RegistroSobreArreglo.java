package ar.uba.fi.cb100.clases.a2026.c02.tps.tp1;

import java.util.Arrays;

/** Implementa el contrato sobre un arreglo que crece a mano. */
public class RegistroSobreArreglo implements RegistroDePrestamos{

    private Prestamo[] prestamos = new Prestamo[8];

    private int usados = 0;

    /**
     * Registra un prestamo. Si el arreglo está lleno, duplica su capacidad antes de agregarlo.
     *
     * Precondicion: p no es null.
     * Postcondicion: el prestamo queda registrado; si el arreglo estaba lleno,
     * duplica su capacidad antes de agregarlo. Modifica el estado del registro.
     *
     * @param p el prestamo a registrar.
     */
    @Override
    public void registrar(Prestamo p) {
        if (usados == prestamos.length) {
            prestamos = Arrays.copyOf(prestamos, prestamos.length * 2);
        }
        prestamos[usados] = p;
        usados += 1;
    }

    /**
     * Devuelve la cantidad de prestamos registrados.
     *
     * Precondicion: ninguna.
     * Postcondicion: devuelve la cantidad de prestamos registrados. No modifica el estado del registro.
     *
     * @return la cantidad de prestamos registrados.
     */
    @Override
    public int cantidad() {

        return usados;
    }

    /**
     * Devuelve el prestamo del índice i.
     *
     * Precondicion: 0 <= i < cantidad().
     * Postcondicion: devuelve el prestamo del índice i. Si el índice es menor a 0
     * o mayor al número de índices, lanza IndexOutOfBoundsException. No modifica
     * el estado del registro.
     *
     * @param i el índice del prestamo.
     * @return el prestamo del índice i.
     */
    @Override
    public Prestamo obtener(int i) {
        if (i < 0 || i > usados - 1) {
            throw new IndexOutOfBoundsException("El indice a obtener es invalido");
        }
        return prestamos[i];
    }

    /**
     * Devuelve un arreglo con los padrones distintos en orden de aparición.
     *
     * Precondicion: ninguna.
     * Postcondicion: devuelve un arreglo con los padrones distintos en orden de
     * aparición. Busca si el padron a agregar ya se encuentra, si es así no lo
     * agrega. No modifica el estado del registro.
     *
     * @return los padrones distintos, en orden de aparición.
     */
    @Override
    public int[] padrones() {
        int maximos = usados;

        int[] padronesDistintos = new int[maximos];

        int distintos = 0;

        for (int j = 0; j < usados; j++) {
            int padronNuevo = prestamos[j].padron();
            boolean esNuevo = true;

            for (int k = 0; k < distintos; k++) {
                if (padronNuevo == padronesDistintos[k]) {
                    esNuevo = false;
                }
            }
            if (esNuevo) {
                padronesDistintos[distintos] = padronNuevo;
                distintos += 1;
            }
        }

        padronesDistintos = Arrays.copyOf(padronesDistintos, distintos);

        return padronesDistintos;
    }

    /**
     * Devuelve los prestamos del padron pedido.
     *
     * Precondicion: ninguna.
     * Postcondicion: devuelve los prestamos del padron pedido. Si no tiene,
     * devuelve un arreglo vacío. No modifica el estado del registro.
     *
     * @param padron el padron pedido.
     * @return los prestamos del padron pedido, o un arreglo vacío si no tiene.
     */
    @Override
    public Prestamo[] prestamosDe(int padron) {
        int maximo = usados;

        Prestamo[] prestamosPorPadron = new Prestamo[maximo];

        int cantidadDePrestamos = 0;

        for (int i = 0; i < usados; i++) {
            if (prestamos[i].padron() == padron) {
                prestamosPorPadron[cantidadDePrestamos] = prestamos[i];
                cantidadDePrestamos += 1;
            }
        }

        prestamosPorPadron = Arrays.copyOf(prestamosPorPadron, cantidadDePrestamos);

        return prestamosPorPadron;
    }

    /**
     * Devuelve el ranking de los titulos más pedidos.
     *
     * Precondicion: ninguna.
     * Postcondicion: devuelve el ranking de los titulos más pedidos. Si hay empate
     * numérico, desempata alfabéticamente. No modifica el estado del registro.
     *
     * @param n cantidad de titulos del ranking.
     * @return el ranking de los titulos más pedidos.
     */
    @Override
    public String[] titulosMasPedidos(int n) {
        int maximo = usados;

        int distintos = 0;

        String[] titulos = new String[maximo];

        int[] conteo = new int[maximo];

        for (int i = 0; i < maximo; i++) {
           String titulo = prestamos[i].titulo();

            int sinEncontrar = -1;

            for (int j = 0; j < distintos; j++) {
                if(titulo.equals(titulos[j])) {
                    sinEncontrar = j;
                }
            }
            if (sinEncontrar == -1) {
                titulos[distintos] = titulo;

                conteo[distintos] += 1;

                distintos += 1;

            } else {
                conteo[sinEncontrar] += 1;
            }
        }
        String[] devuelta = new String[Math.min(n, distintos)];

        for (int j = 0; j < devuelta.length; j++) {
            int indiceMejor = 0;

            for (int i = 0; i < distintos; i ++) {
                if (conteo[i] > conteo[indiceMejor]) {
                    indiceMejor = i;
                }
                if(conteo[i] == conteo[indiceMejor]) {
                    int cualMejor = titulos[i].compareTo(titulos[indiceMejor]);

                    if (cualMejor < 0) {
                        indiceMejor = i;
                    }
                }
            }
            devuelta[j] = titulos[indiceMejor];
            conteo[indiceMejor] = -1;
        }

        return devuelta;
    }
}
