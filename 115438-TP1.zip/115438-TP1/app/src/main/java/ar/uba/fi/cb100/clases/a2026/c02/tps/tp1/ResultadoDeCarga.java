package ar.uba.fi.cb100.clases.a2026.c02.tps.tp1;

/**
 * Representa el resultado de una carga.
 *
 * @param registro el registro con los préstamos válidos.
 * @param errores los mensajes de error.
 * @param lineasDeDatos la cantidad de líneas de datos.
 */
public record ResultadoDeCarga(RegistroDePrestamos registro, String[] errores, int lineasDeDatos) {

}