package ar.uba.fi.cb100.clases.a2026.c02.tps.tp1;

/**
 * Representa una fila del reporte por socio.
 *
 * @param padron el padrón del socio.
 * @param socio el nombre.
 * @param prestamos la cantidad de prestamos.
 * @param diasDeAtraso los dias de atraso (si aplica).
 * @param multa el total de la multa (si aplica).
 * @param estado el estado del socio.
 */
public record FilaDeSocio(int padron, String socio, int prestamos, int diasDeAtraso, int multa, String estado) {

}
