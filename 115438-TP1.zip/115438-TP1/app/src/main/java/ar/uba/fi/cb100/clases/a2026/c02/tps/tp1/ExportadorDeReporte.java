package ar.uba.fi.cb100.clases.a2026.c02.tps.tp1;

import java.io.IOException;
import java.nio.file.Path;

/**
 * Es el contrato (TDA) de un exportador de reporte que define como escribir las
 * filas al disco y que extension utiliza.
 */
public interface ExportadorDeReporte {

    /**
     * Exporta las filas del reporte al archivo destino.
     *
     * Precondicion: ninguna.
     * Postcondicion: escribe las filas del reporte en el archivo destino.
     *
     * @param filas las filas del reporte.
     * @param destino el archivo donde se escribe.
     * @throws IOException si no se puede escribir el archivo.
     */
    void exportar(FilaDeSocio[] filas, Path destino) throws IOException;

    /**
     * Devuelve la extension del archivo.
     *
     * Precondicion: ninguna.
     * Postcondicion: devuelve la extension del archivo. No modifica el estado.
     *
     * @return la extension del archivo.
     */
    String extension();

}
