package ar.uba.fi.cb100.clases.a2026.c02.tps.tp1;

import ar.uba.fi.cb100.librerias.excel.ExcelUtils;

import java.io.IOException;
import java.nio.file.Path;

/**
 * Implementa el contrato de ExportadorDeReporte sobre el reporte como plantilla
 * de excel con extension xlsx.
 */
public class ExportadorXlsx implements ExportadorDeReporte{

    /**
     * Escribe el reporte como planilla .xlsx usando ExcelUtils.
     *
     * Precondicion: ninguna.
     * Postcondicion: escribe el reporte como planilla .xlsx usando ExcelUtils, con
     * una fila de encabezados y una fila por socio con sus respectivos datos.
     *
     * @param filas las filas del reporte.
     * @param destino el archivo donde se escribe.
     * @throws IOException si no se puede escribir el archivo.
     */
    @Override
    public void exportar(FilaDeSocio[] filas, Path destino) throws IOException {
        String[] encabezados = { "Padron", "Socio", "Prestamos", "DiasAtraso", "Multa", "Estado" };

        Object[][] datos = new Object[filas.length][];

        for (int i = 0; i < filas.length; i++) {
            datos[i] = new Object[] { filas[i].padron(), filas[i].socio(), filas[i].prestamos(), filas[i].diasDeAtraso(), filas[i].multa(), filas[i].estado()};
        }
        ExcelUtils.escribir(destino, "Multas", encabezados, datos);

    }

    /**
     * Devuelve la extension del archivo.
     *
     * Precondicion: ninguna.
     * Postcondicion: devuelve la extension del archivo. No modifica el estado.
     *
     * @return la extension del archivo.
     */
    @Override
    public String extension() {
        return "xlsx";
    }
}
