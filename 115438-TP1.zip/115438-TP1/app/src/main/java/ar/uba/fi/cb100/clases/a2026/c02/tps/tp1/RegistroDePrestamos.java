package ar.uba.fi.cb100.clases.a2026.c02.tps.tp1;

/**
 * Es el contrato (TDA) de un registro de prestamos que define las operaciones,
 * sin explicar como se guardan los datos.
 */
public interface RegistroDePrestamos {

    /**
     * Registra un préstamo en el registro.
     *
     * Precondicion: p no es null.
     * Postcondicion: el préstamo queda registrado. Modifica el estado del registro.
     *
     * @param p el préstamo a registrar.
     */
    void registrar(Prestamo p);

    /**
     * Devuelve la cantidad de prestamos registrados.
     *
     * Precondicion: ninguna.
     * Postcondicion: devuelve la cantidad de prestamos registrados. No modifica el estado del registro.
     *
     * @return la cantidad de prestamos registrados.
     */
    int cantidad();

    /**
     * Devuelve el préstamo en la posición i.
     *
     * Precondicion: 0 <= i < cantidad().
     * Postcondicion: devuelve el préstamo en la posición i. Si i es inválido,
     * lanza IndexOutOfBoundsException. No modifica el estado del registro.
     *
     * @param i la posición del préstamo.
     * @return el préstamo en la posición i.
     */
    Prestamo obtener(int i);

    /**
     * Devuelve todos los padrones sin repetidos en orden de aparición.
     *
     * Precondicion: ninguna.
     * Postcondicion: devuelve todos los padrones sin repetidos en orden de aparición.
     * No modifica el estado del registro.
     *
     * @return los padrones sin repetidos, en orden de aparición.
     */
    int[] padrones();

    /**
     * Devuelve el o los prestamos del padrón pedido.
     *
     * Precondicion: ninguna.
     * Postcondicion: devuelve el o los prestamos del padrón pedido; si no hay ninguno,
     * devuelve un arreglo vacío. No modifica el estado del registro.
     *
     * @param padron el padrón pedido.
     * @return los prestamos de ese padrón, o un arreglo vacío si no hay ninguno.
     */
    Prestamo[] prestamosDe(int padron);

    /**
     * Devuelve un ranking con los títulos más pedidos.
     *
     * Precondicion: ninguna.
     * Postcondicion: devuelve un ranking con los títulos más pedidos. Si hay empate,
     * hace un desempate alfabético. No modifica el estado del registro.
     *
     * @param n cantidad de títulos del ranking.
     * @return el ranking de los títulos más pedidos.
     */
    String[] titulosMasPedidos(int n);
}
