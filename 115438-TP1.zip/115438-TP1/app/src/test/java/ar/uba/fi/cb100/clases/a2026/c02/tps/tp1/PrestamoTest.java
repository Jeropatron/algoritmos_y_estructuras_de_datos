package ar.uba.fi.cb100.clases.a2026.c02.tps.tp1;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

public class PrestamoTest {

    @Test
    @DisplayName("Vencimiento es 14 dias despues del retiro")
    void vencimientoEsCatorceDidasDespuesDelRetiro() {
        LocalDate retiro = LocalDate.parse("2026-03-02");
        LocalDate vencimiento = LocalDate.parse("2026-03-16");

        Prestamo prestamoLibro = new Prestamo(retiro, 115324, "Patron", "B335D", "Rebelion en la granja", null);

        assertEquals(vencimiento, prestamoLibro.vencimiento());
    }

    @Test
    @DisplayName("Rechaza un padron invalido")
    void rechazaPadronInvalido() {
        assertThrows(IllegalArgumentException.class, () -> new Prestamo(LocalDate.parse("2026-03-02"), -3, "Gomez", "V35Q", "El retrato de Dorian Gray", null));
    }

    @Test
    @DisplayName("Rechaza un socio nulo o un socio vacio")
    void rechazaSocioInvalido() {
        assertThrows(IllegalArgumentException.class, () -> new Prestamo(LocalDate.parse("2026-03-02"), 112543, null, "V35Q", "El retrato de Dorian Gray", null));

        assertThrows(IllegalArgumentException.class, () -> new Prestamo(LocalDate.parse("2026-03-02"), 112543, "", "V35Q", "El retrato de Dorian Gray", null));
    }

    @Test
    @DisplayName("Rechaza un isbn nulo o un isbn vacio")
    void rechazaIsbnInvalido() {
        assertThrows(IllegalArgumentException.class, () -> new Prestamo(LocalDate.parse("2026-03-02"), 112543, "Gomez", null, "El retrato de Dorian Gray", null));

        assertThrows(IllegalArgumentException.class, () -> new Prestamo(LocalDate.parse("2026-03-02"), 112543, "Gomez", "", "El retrato de Dorian Gray", null));
    }

    @Test
    @DisplayName("Rechaza un titulo nulo o un titulo vacio")
    void rechazaTituloInvalido() {
        assertThrows(IllegalArgumentException.class, () -> new Prestamo(LocalDate.parse("2026-03-02"), 112543, "Gomez", "V35Q", null, null));

        assertThrows(IllegalArgumentException.class, () -> new Prestamo(LocalDate.parse("2026-03-02"), 112543, "Gomez", "V35Q", "", null));
    }

    @Test
    @DisplayName("Rechaza una devolucion no nula previa al retiro")
    void rechazaDevolucionInvalida() {
        assertThrows(IllegalArgumentException.class, () -> new Prestamo(LocalDate.parse("2026-03-02"), 112543, "Gomez", "V35Q", "El retrato de Dorian Gray", LocalDate.parse("2025-03-02")));
    }

    @Test
    @DisplayName("Devuelve 0 en atraso con una devolucion en el dia del vencimiento")
    void AtrasoCeroCuandoSeDevolvioATiempo() {
        LocalDate retiro = LocalDate.parse("2026-03-02");
        LocalDate vencimiento = LocalDate.parse("2026-03-16");

        Prestamo prestamo = new Prestamo(retiro, 112354, "Castro", "N349L", "La republica", vencimiento);

        assertEquals(0, prestamo.diasDeAtraso(vencimiento));

        Prestamo devueltoAntes = new Prestamo(retiro, 112354, "Perez", "P9934V", "La republica", LocalDate.parse("2026-03-13"));

        assertEquals(0, devueltoAntes.diasDeAtraso(vencimiento));
    }

    @Test
    @DisplayName("Se cuenta el atraso una vez pasado el vencimiento")
    void cuentaDeAtrasoPasadoElVencimiento() {
        LocalDate retiro = LocalDate.parse("2026-03-02");
        LocalDate vencimiento = LocalDate.parse("2026-03-16");
        LocalDate corte = LocalDate.parse("2026-03-26");

        Prestamo prestamo = new Prestamo(retiro, 112354, "Castro", "N349L", "La republica", null);

        assertEquals(10, prestamo.diasDeAtraso(corte));
    }

    @Test
    @DisplayName("Se verifica que la multa no exceda los 3000")
    void multaNoExcedeLimite() {
        LocalDate retiro = LocalDate.parse("2026-03-02");
        LocalDate vencimiento = LocalDate.parse("2026-03-16");
        LocalDate corte = LocalDate.parse("2026-12-26");

        Prestamo prestamo = new Prestamo(retiro, 112354, "Gonzales", "F045F", "1984", null);

        assertEquals(3000, prestamo.multa(corte));
    }
}
