package ar.uba.fi.cb100.clases.a2026.c02.tps.tp1;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.time.LocalDate;

public class RegistroSobreArregloTest {

    @Test
    @DisplayName("Crecimiento mas alla de la capacidad")
    void creceMasAllaDeLaCapacidad() {
        RegistroSobreArreglo r = new RegistroSobreArreglo();

        for (int i = 1; i < 21; i++) {
            r.registrar(new Prestamo(LocalDate.parse("2026-03-02"), i, "Gomez", "C94ND", "El extraño caso del dr. jekyll y mr. hyde", null));
        }

        assertEquals(20, r.cantidad());
    }

    @Test
    @DisplayName("Verificacion de padrones no repetidos")
    void padronesNoSeRepiten() {
        RegistroSobreArreglo r = new RegistroSobreArreglo();

        r.registrar(new Prestamo(LocalDate.parse("2026-03-02"), 134365, "Gomez", "C94ND", "El extraño caso del dr. jekyll y mr. hyde", null));

        r.registrar(new Prestamo(LocalDate.parse("2026-07-02"), 119543, "Gonzales", "GH393J", "Asesinato en el Orient Express", null));

        r.registrar(new Prestamo(LocalDate.parse("2026-02-02"), 104593, "Perez", "V0F40", "El príncipe feliz y otros cuentos", LocalDate.parse("2026-05-15")));

        r.registrar(new Prestamo(LocalDate.parse("2026-10-07"), 134365, "Gomez", "JH406G", "El flautista de Hamelín", null));

        r.registrar(new Prestamo(LocalDate.parse("2026-03-02"), 120223, "Castro", "P40L4", "20000 leguas de viaje submarino", null));

        assertArrayEquals(new int[] {134365, 119543, 104593, 120223}, r.padrones());
    }

    @Test
    @DisplayName("Verificar que el arreglo vuelve vacio al pedir un padron inexistente")
    void verificarPeticionVacioConPadronInexistente() {
        RegistroSobreArreglo r = new RegistroSobreArreglo();

        r.registrar(new Prestamo(LocalDate.parse("2026-09-02"), 124135, "Rodriguez", "P02FA", "Los dias de Birmania", null));

        r.registrar(new Prestamo(LocalDate.parse("2026-07-02"), 109773, "Fernandez", "Y4F7E", "Secuestrado", null));

        r.registrar(new Prestamo(LocalDate.parse("2026-02-02"), 113423, "Lopez", "UJ63H", "El ser y la nada", LocalDate.parse("2026-02-08")));

        assertEquals(0, r.prestamosDe(999).length);
    }

    @Test
    @DisplayName("Verificamos la devolucion por cantidad y desempate alfabetico")
    void devolucionOrdenadosPorCantidad() {
        RegistroSobreArreglo r = new RegistroSobreArreglo();

        r.registrar(new Prestamo(LocalDate.parse("2026-07-02"), 115437, "Sanchez", "Y4F7E", "Secuestrado", null));

        r.registrar(new Prestamo(LocalDate.parse("2026-09-02"), 103537, "Diaz", "L042GX", "Los dias de Birmania", null));

        r.registrar(new Prestamo(LocalDate.parse("2026-05-17"), 158003, "Romero", "L042GX", "Los dias de Birmania", LocalDate.parse("2026-05-26")));

        r.registrar(new Prestamo(LocalDate.parse("2026-11-13"), 115437, "Lopez", "Y4F7E", "Secuestrado", null));

        assertArrayEquals(new String[] {"Los dias de Birmania", "Secuestrado"}, r.titulosMasPedidos(2));
    }

}
