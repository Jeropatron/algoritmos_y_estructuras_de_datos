package ar.uba.fi.cb100.clases.a2026.c02.tps.tp1;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;

public class ExportadorCsvTest {

    @Test
    @DisplayName("Verificamos la correcta lectura de datos")
    void verificacionDeLectura() throws IOException {
        FilaDeSocio[] filaDeSocios = {
                new FilaDeSocio(121141,"Gonzales",2,0,0,"AL_DIA"),
                new FilaDeSocio(115438,"Patron", 1, 3, 400, "CON_DEUDA")
        };
        Path archivoTemp = Files.createTempFile("reporte", ".csv");

        new ExportadorCsv().exportar(filaDeSocios, archivoTemp);

        List<String> filasLeidas = Files.readAllLines(archivoTemp);

        assertEquals("padron;socio;prestamos;dias_atraso;multa;estado", filasLeidas.getFirst());

        assertEquals("121141;Gonzales;2;0;0;AL_DIA", filasLeidas.get(1));

        assertEquals("115438;Patron;1;3;400;CON_DEUDA", filasLeidas.get(2));
    }
}
